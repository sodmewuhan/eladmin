/*
*  Copyright 2019-2020 Zheng Jie
*
*  Licensed under the Apache License, Version 2.0 (the "License");
*  you may not use this file except in compliance with the License.
*  You may obtain a copy of the License at
*
*  http://www.apache.org/licenses/LICENSE-2.0
*
*  Unless required by applicable law or agreed to in writing, software
*  distributed under the License is distributed on an "AS IS" BASIS,
*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*  See the License for the specific language governing permissions and
*  limitations under the License.
*/
package me.zhengjie.fish.service.impl;

import me.zhengjie.fish.domain.BoxInfoT;
import me.zhengjie.utils.ValidationUtil;
import me.zhengjie.utils.FileUtil;
import lombok.RequiredArgsConstructor;
import me.zhengjie.fish.repository.BoxInfoTRepository;
import me.zhengjie.fish.service.BoxInfoTService;
import me.zhengjie.fish.service.dto.BoxInfoTDto;
import me.zhengjie.fish.service.dto.BoxInfoTQueryCriteria;
import me.zhengjie.fish.service.mapstruct.BoxInfoTMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import me.zhengjie.utils.PageUtil;
import me.zhengjie.utils.QueryHelp;
import java.util.List;
import java.util.Map;
import java.io.IOException;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.LinkedHashMap;

/**
* @website https://el-admin.vip
* @description 服务实现
* @author sodmeuwhan
* @date 2020-12-06
**/
@Service
@RequiredArgsConstructor
public class BoxInfoTServiceImpl implements BoxInfoTService {

    private final BoxInfoTRepository boxInfoTRepository;
    private final BoxInfoTMapper boxInfoTMapper;

    @Override
    public Map<String,Object> queryAll(BoxInfoTQueryCriteria criteria, Pageable pageable){
        Page<BoxInfoT> page = boxInfoTRepository.findAll((root, criteriaQuery, criteriaBuilder) -> QueryHelp.getPredicate(root,criteria,criteriaBuilder),pageable);
        return PageUtil.toPage(page.map(boxInfoTMapper::toDto));
    }

    @Override
    public List<BoxInfoTDto> queryAll(BoxInfoTQueryCriteria criteria){
        return boxInfoTMapper.toDto(boxInfoTRepository.findAll((root, criteriaQuery, criteriaBuilder) -> QueryHelp.getPredicate(root,criteria,criteriaBuilder)));
    }

    @Override
    @Transactional
    public BoxInfoTDto findById(Integer id) {
        BoxInfoT boxInfoT = boxInfoTRepository.findById(id).orElseGet(BoxInfoT::new);
        ValidationUtil.isNull(boxInfoT.getId(),"BoxInfoT","id",id);
        return boxInfoTMapper.toDto(boxInfoT);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public BoxInfoTDto create(BoxInfoT resources) {
        if(boxInfoTRepository.findByBoxNumber(resources.getBoxNumber()) != null){
            throw new EntityExistException(BoxInfoT.class,"box_number",resources.getBoxNumber());
        }
        return boxInfoTMapper.toDto(boxInfoTRepository.save(resources));
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void update(BoxInfoT resources) {
        BoxInfoT boxInfoT = boxInfoTRepository.findById(resources.getId()).orElseGet(BoxInfoT::new);
        ValidationUtil.isNull( boxInfoT.getId(),"BoxInfoT","id",resources.getId());
        boxInfoT1 = boxInfoTRepository.findByBoxNumber(resources.getBoxNumber());
        if(boxInfoT1 != null && !boxInfoT1.getId().equals(boxInfoT.getId())){
            throw new EntityExistException(BoxInfoT.class,"box_number",resources.getBoxNumber());
        }
        boxInfoT.copy(resources);
        boxInfoTRepository.save(boxInfoT);
    }

    @Override
    public void deleteAll(Integer[] ids) {
        for (Integer id : ids) {
            boxInfoTRepository.deleteById(id);
        }
    }

    @Override
    public void download(List<BoxInfoTDto> all, HttpServletResponse response) throws IOException {
        List<Map<String, Object>> list = new ArrayList<>();
        for (BoxInfoTDto boxInfoT : all) {
            Map<String,Object> map = new LinkedHashMap<>();
            map.put(" 盒子类型", boxInfoT.getBoxTypoId());
            map.put("盒子编号", boxInfoT.getBoxNumber());
            map.put("注册时间", boxInfoT.getRegisteTime());
            map.put("创建人", boxInfoT.getCreateDate());
            map.put("创建时间", boxInfoT.getCreateBy());
            map.put("最后更新人", boxInfoT.getLastUpdateDate());
            map.put("最后更新时间", boxInfoT.getLastUpdateBy());
            map.put("塘口ID", boxInfoT.getFishPondId());
            list.add(map);
        }
        FileUtil.downloadExcel(list, response);
    }
}